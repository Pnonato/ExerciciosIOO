



public class App {
    public static void main(String[] args) throws Exception {
        
        
        Market produto1 = new Market("Maça", 1.0f, 10);
        Market produto2 = new Market("Banana", 2.0f, 2);
        
        produto1.comprar(5);
        produto1.vender(3);

        produto2.comprar(2);
        produto2.vender(1);


        produto1.mostrarEstoque();
        produto2.mostrarEstoque();

    
    }
}
