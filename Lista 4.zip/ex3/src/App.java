import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
       
        Televisao televisao = new Televisao();
        Scanner scanner = new Scanner(System.in);


        System.out.println("O que deseja fazer com a TV? ");

        while(true){
            
            System.out.println("\nO que você deseja fazer?");
            System.out.println("1. Ligar a TV");
            System.out.println("2. Desligar a TV");
            System.out.println("3. Quebrar a TV");
            System.out.println("4. Observar estado da TV");
            System.out.println("0. Sair");

            int escolha = scanner.nextInt();
            
            switch (escolha) {
                case 1:
                    televisao.ligar();
                    break;
                
                case 2:
                    televisao.desligar();
                    break;

                case 3:
                    televisao.quebrar();
                    break;

                case 4:
                    televisao.oberservar();
                    break;

                case 0:
                    System.out.println("Saindo....");
                    break;
                default:
                    System.out.println("Opção inválida!");
                    break;
            }

            scanner.close();

        }
        
    }
}
