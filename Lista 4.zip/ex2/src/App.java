public class App {
    public static void main(String[] args) throws Exception {
        
        Lampada lampada = new Lampada();

        System.out.println("Começo: ");
        lampada.mostrarEstado();



        System.out.println("Ascendi a lampada: ");
        lampada.acender();
        lampada.mostrarEstado();

         System.out.println("Apaguei a lampada: ");
        lampada.apagar();
        lampada.mostrarEstado();


    }
}
