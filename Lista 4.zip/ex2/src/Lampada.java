public class Lampada{
    
    private String estado;
    
    public Lampada(){
        estado = "Apagado"; // começa apagada
    }

    public void acender(){
        estado = "Aceso";
    }

    public void apagar(){
        estado = "Apagado";
    }

    public void mostrarEstado(){
        System.out.println("Estado da lamapada: " + estado);
    }

    
}