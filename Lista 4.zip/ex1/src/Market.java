public class Market{
    //atributos
    String nome;
    float preco;
    int quantidadeDisp;

    //metodo construtor
    public Market(String nome, float preco, int quantidadeDisp){
        
         this.nome = nome;   
        this.preco = preco;
        this.quantidadeDisp = quantidadeDisp;

    }

    public void comprar(int quantidade){
        quantidadeDisp += quantidade;
        System.out.println("Comprado " + quantidade + " unidades de " + nome);
    }

    public void vender(int quantidade){
       
        if(quantidade <= quantidadeDisp){
            quantidadeDisp -= quantidade;
             System.out.println("Vendido " + quantidade + " unidades de " + nome);
        } else {
             System.out.println("Quntidade nao disponivel para a venda");
        }

    }

    public void mostrarEstoque(){
        System.out.println("Quantidade de " + nome  + ": "  + quantidadeDisp);
    }
}