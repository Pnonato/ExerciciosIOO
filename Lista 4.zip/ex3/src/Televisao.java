public class Televisao{
    
    private String estado;


    public Televisao() {
       
        estado = "Desligado";

    }

    public void ligar(){
        
        estado = "Ligado";
    }

    public void desligar(){
        
        estado = "Desligado";
    }

    public void quebrar(){
        estado = "Quebrado";
    }

    public void oberservar(){
        System.out.println("Estado da televisao: " + estado);
    }
}